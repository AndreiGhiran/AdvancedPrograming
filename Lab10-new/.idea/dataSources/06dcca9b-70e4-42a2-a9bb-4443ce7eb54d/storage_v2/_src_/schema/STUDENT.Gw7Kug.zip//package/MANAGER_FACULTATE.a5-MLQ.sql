create PACKAGE manager_facultate IS
      g_today_date   DATE:= SYSDATE;
      CURSOR lista_studenti IS SELECT nr_matricol, nume, prenume, grupa, an FROM studenti ORDER BY nume;
      CURSOR haha;
      CURSOR prietenii_prietenilor IS SELECT nume, prenume FROM studenti WHERE id in
       (
        SELECT id_student2 FROM prieteni where id_student1 in
        ( select id_student2 from prieteni where id_student1=10));
      v_result studnet.id%type;
      result2 studenti.id%type;
      CURSOR max_id IS
        SELECT max(id) FROM studenti;
     PROCEDURE adauga_student (nume studenti.nume%type, prenume studenti.prenume%type);
     PROCEDURE sterge_student (nr_matr studenti.nr_matricol%type);
END manager_facultate;
/

