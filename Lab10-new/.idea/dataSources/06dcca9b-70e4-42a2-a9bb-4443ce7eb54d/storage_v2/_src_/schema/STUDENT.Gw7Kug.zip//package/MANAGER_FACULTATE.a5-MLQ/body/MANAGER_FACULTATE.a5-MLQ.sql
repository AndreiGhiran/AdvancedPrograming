create PACKAGE BODY manager_facultate IS

    nume_facultate VARCHAR2(100) := 'Facultatea de Informatica din IASI';

    FUNCTION calculeaza_varsta (data_nastere DATE) RETURN INT IS
    BEGIN
       RETURN FLOOR((g_today_date - data_nastere)/365);
    END calculeaza_varsta;   
    
    FUNCTION compile_id(last_id NUMBER) RETURN NUMBER AS
    BEGIN        
        v_reuslt := last_id + 1;
        RETURN v_result;
    END compile_id;
    
    FUNCTION get_id(nr_matri studenti.nr_matricol%type) RETURN VARCHAR AS
    BEGIN
        cursor haha IS SELECT id from studenti where nr_matricol=nr_matri;
        fetch haha into result2;
        RETURN result2;
    END get_id;
    
    PROCEDURE adauga_student (nume studenti.nume%type, prenume studenti.prenume%type) 
       IS BEGIN
           DBMS_OUTPUT.PUT_LINE('Exemplu apel functie privata: '|| calculeaza_varsta(to_date('01/01/1990','DD/MM/YYYY')));
           DBMS_OUTPUT.PUT_LINE(compile_id(max_id));
    END adauga_student;
    
    PROCEDURE sterge_student (nr_matr studenti.nr_matricol%type) IS
    BEGIN
        id_student := get_id(nr_matr);
        DBMS_OUTPUT.PUT_LINE(id_student);
--       DELETE FROM prieteni WHERE nr_matr
    END sterge_student;
    
END manager_facultate;
/

