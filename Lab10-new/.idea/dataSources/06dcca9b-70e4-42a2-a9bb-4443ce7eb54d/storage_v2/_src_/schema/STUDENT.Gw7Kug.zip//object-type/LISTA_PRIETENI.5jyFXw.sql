create TYPE lista_prieteni AS TABLE OF VARCHAR2(6);
/

